import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule} from '@angular/router';

import { AppComponent } from './app.component';
import { TableauComponent } from '../eleves/tableau.component';
import { STEAMComponent } from './steam/steam.component';
import { SteamService } from './steam.service';

@NgModule({
  declarations: [
    AppComponent,
    TableauComponent,
    STEAMComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot([
      {
        path: '',
        component: TableauComponent
      },
      {
        path: '',
        component: TableauComponent
      }
    ])
  ],
  providers: [SteamService],
  bootstrap: [AppComponent]
})
export class AppModule { }
